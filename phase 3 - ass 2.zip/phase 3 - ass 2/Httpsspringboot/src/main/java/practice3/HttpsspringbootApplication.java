package practice3;

import org.springframework.boot.SpringApplication; 
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("practice3")
public class HttpsspringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpsspringbootApplication.class, args);
	}

}
