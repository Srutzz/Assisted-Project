package assistedproject4;

public class selectionsort {
	public static void main(String[] args) 
	{
	    int[] arr={3,1,6,2,4,9,0};
	    int l=arr.length;
	    for(int i=0;i<l-1;i++)
	    {
            int index=i;
            for(int j=i+1;j<l;j++)
            {
                if(arr[j]<arr[index])
                {
                    index=j;
                }
            }
            int small=arr[index];
            arr[index]=arr[i];
            arr[i]=small;
        }
	    System.out.println("Sorted array are ");
	    for(int i:arr)
	    {
	        System.out.println(i);
	    }
	}
}
