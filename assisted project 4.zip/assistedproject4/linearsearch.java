package assistedproject4;
import java.util.Scanner;
public class linearsearch {
	public static void main(String[] args)
	{
        int[] arr={1,2,3,4,5,6,7,8,9};
        int l=arr.length;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter element to be searched");
        int x=sc.nextInt();
        int n=0;
        for (int i=0;i<l-1;i++)
        {
            if (arr[i]==x) 
            {
                n=i;
            }
        }
        if(n==-1)
        {
            System.out.println("Element not found");
        } 
        else 
        {
            System.out.println("Element found at position "+n);
        }
    }

}
