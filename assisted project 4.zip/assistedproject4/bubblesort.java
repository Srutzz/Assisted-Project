package assistedproject4;

public class bubblesort {
    public static void main(String[] args)
    {
         int[] arr={3,1,6,2,4,9,0};
         int l=arr.length;
         int temp=0;
         for(int i=0;i<l;i++){
             for (int j=1;j<l;j++)
             {
                 if(arr[j-1]>arr[j])
                 {
                     temp=arr[j-1];
                     arr[j-1]=arr[j];
                     arr[j]=temp;
                 }
             }
         }
         System.out.println("Sorted array are ");
         for(int i=0;i<l;i++)
         {
             System.out.println(arr[i]);
         }
    }
}
