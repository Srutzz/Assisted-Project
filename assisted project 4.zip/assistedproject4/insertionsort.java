package assistedproject4;
public class insertionsort {
    public static  void main(String[] args)
    {
    	int[] arr={3,1,6,2,4,9,0};
        int l=arr.length;
        for(int j=1;j<l;j++)
        {
            int k=arr[j];
            int i=j-1;
            while ((i>-1)&&(arr[i]>k))
            {
                arr[i+1]=arr[i];
                i--;
            }
            arr[i+1]=k;
        }
        System.out.println("Sorted array are ");
        for(int i=0;i<l;i++)
        {
            System.out.println(arr[i]);
        }
     }
}
