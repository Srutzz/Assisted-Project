package assistedproject4;
import java.util.Arrays;
import java.util.Scanner;
public class exponentialsearch {
	public static  void main(String[] args){

	    int[] arr = {1,2,3,4,5,6,7,8,9};
	    int l=arr.length;
	    Scanner sc=new Scanner(System.in);
        System.out.println("Enter element to be searched");
        int x=sc.nextInt();
        int o;
	    if(arr[0]==x)
	    {
            o=0;
        }
        int i=1;
        while(i<l&&arr[i]<=x)
        {
            i=i*2;
        }
        o=Arrays.binarySearch(arr,i/2,Math.min(i,l),x);
	    if(o<0)
	    {
	       System.out.println("Element not found");
	    }
	    else 
	    {
	        System.out.println("Element present at index : "+o);
	    }
     }
}
