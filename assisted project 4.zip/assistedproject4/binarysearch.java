package assistedproject4;
import java.util.Scanner;
public class binarysearch {
	public static void main(String args[])
	{  
        int arr[]={1,2,3,4,5,6,7,8,9};  
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter element to be searched");
        int x=sc.nextInt();
        int n=arr.length;
        int l=n-1; 
        int f=0;
        int mid=(f+l)/2;  
		while(f<=l)
		{  
		    if (arr[mid]<x)
		    {  
		        f=mid+1;     
		    }
		    else if (arr[mid]==x)
		    {  
		        System.out.println("Element is found at index: " + mid);  
		        break;  
		    }
		    else
		    {  
		         l=mid-1;  
		    }  
		    mid=(f+l)/2;  
	    }  
		if (f>l)
		{  
	        System.out.println("Element is not found!");  
		} 
 } 
}
