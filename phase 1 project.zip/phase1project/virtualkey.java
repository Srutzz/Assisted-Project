package phase1project;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class virtualkey {
    public static void main(String[] args)
    {
    	System.out.println("\t\tVirtual Key for Your Repositories");
    	System.out.println("\t\t\tDeveloped by");
    	System.out.println("\t\t\tSruthi G S");
    	System.out.println("This application was developed to perform the following functions: \n1. Retrieving the file names in ascending order. \n2. To perform add, delete and search operation in the files");
    	main1("folder");
    	firstdisp();
    }
    
    public static void main1(String folder)
	{
		File fol=new File(folder);
		if (!fol.exists())
		{
			fol.mkdirs();
	    }
    }
    
    public static void firstdisp() 
    {
		boolean r=true;
		Scanner sc=new Scanner(System.in);
		do {
			try {
				System.out.println("\n\nSelect options from the below\n\n1) Retrieve all files\n2) Displaying the file operations\n3) Exit the application\n");
				int in=sc.nextInt();
				switch (in) {
				case 1:
			        displayallfiles("folder");
					break;
				case 2:
					menuoptions();
					break;
				case 3:
					System.out.println("Program exited");
					r=false;
					sc.close();
					System.exit(0);
					break;
				default:
					System.out.println("Please select a valid option");
				}
			} catch (Exception e) 
			{
				System.out.println(e.getClass().getName());
				firstdisp();
			} 
		} while(r==true);
	}
    
    public static void displayallfiles(String path) 
    {
		main1("folder");
		System.out.println("Displaying all files with directory structure in ascending order\n");
		List<String> fileslist=listallfiles(path,0,new ArrayList<String>());
		System.out.println("Displaying all files in ascending order\n");
		Collections.sort(fileslist);
		fileslist.stream().forEach(System.out::println);
	}
    
    public static List<String> listallfiles(String path,int count,List<String> filelist)
    {
		File d=new File(path);
		File[] files=d.listFiles();
		List<File> filesList =Arrays.asList(files);
		Collections.sort(filesList);
		if (files!=null&&files.length>0) 
		{
			for (File file:filesList) 
			{
				System.out.print(" ".repeat(count*2));
				if (file.isDirectory())
				{
					System.out.println("` " + file.getName());
					filelist.add(file.getName());
					listallfiles(file.getAbsolutePath(),count+1,filelist);
				} 
				else
				{
					System.out.println(" "+file.getName());
					filelist.add(file.getName());
				}
			}
		} 
		else 
		{
			System.out.print(" ".repeat(count*2));
			System.out.println("Empty Directory");
		}
		System.out.println();
		return filelist;
	}
    
    public static void menuoptions()
    {
		boolean r=true;
		Scanner sc=new Scanner(System.in);
		do 
		{
			try 
			{
				System.out.println("\n\nSelect any option from the below\n\n1. Add a file\n2. Delete a file\n3. Search for a file\n4. Show Previous Menu");
				main1("folder");
				int in=sc.nextInt();
				switch (in) 
				{
				case 1:
					System.out.println("Enter the name of the file to be added");
					String filetoadd=sc.next();
					createfile(filetoadd,sc);
					break;
				case 2:
					System.out.println("Enter the name of the file to be deleted");
					String filetodelete=sc.next();
					main1("folder");
					List<String> filestodelete=filelocation(filetodelete,"folder");
					String deletion="\nSelect the index of the file to be delete?";
					System.out.println(deletion);
					int idx=sc.nextInt();
					if (idx!=0)
					{
						deletefile(filestodelete.get(idx-1));
					} 
					else 
					{
						for (String path:filestodelete)
						{
							deletefile(path);
						}
					}
					break;
				case 3:
					System.out.println("Enter the name of the file to be searched");
					String filename=sc.next();
					main1("folder");
					filelocation(filename,"folder");
					break;
				case 4:
					return;
				default:
					System.out.println("Please select a valid option");
				}
			} catch (Exception e)
			{
				System.out.println(e.getClass().getName());
				menuoptions();
			}
		} while (r==true);
	}
    
    public static void createfile(String filetoadd,Scanner sc)
    {
		main1("folder");
		Path pathtofile=Paths.get("./folder/"+filetoadd);
		try 
		{
			Files.createDirectories(pathtofile.getParent());
			Files.createFile(pathtofile);
			System.out.println(filetoadd+"created successfully");
			System.out.println("Would you like to add some content in the file? (Y/N)");
			String choice=sc.next().toLowerCase();
			sc.nextLine();
			if (choice.equals("y")) 
			{
				System.out.println("\n\nInput the content\n");
				String content=sc.nextLine();
				Files.write(pathtofile,content.getBytes());
				System.out.println("\nContent written to file "+filetoadd);
			}

		} catch (IOException e) 
		{
			System.out.println("Failed to create file"+filetoadd);
			System.out.println(e.getClass().getName());
		}
	}
    
    public static List<String> filelocation(String filename,String path)
    {
		List<String> filelist=new ArrayList<>();
		searchfile(path, filename,filelist);
		if (filelist.isEmpty()) 
		{
			System.out.println("\n\nCouldn't find any file \n\n");
		} else 
		{
			System.out.println("\n\nFound file at below location:");
			List<String> files = IntStream.range(0, filelist.size()).mapToObj(index -> (index + 1) + ": " + filelist.get(index)).collect(Collectors.toList());
			files.forEach(System.out::println);
		}
		return filelist;
	}
    
    public static void searchfile(String path,String filename,List<String> filelist) 
    {
		File dir=new File(path);
		File[] files=dir.listFiles();
		List<File> fileslist = Arrays.asList(files);
		if (files!=null&&files.length>0) 
		{
			for (File file:fileslist) 
			{
				if (file.getName().startsWith(filename)) 
				{
					filelist.add(file.getAbsolutePath());
				}
				if (file.isDirectory()) 
				{
					searchfile(file.getAbsolutePath(),filename,filelist);
				}
			}
		}
	}
    
    public static void deletefile(String path) 
    {

		File curr=new File(path);
		File[] files=curr.listFiles();
		if (files!=null&&files.length>0) 
		{
			for (File file:files)
			{
				String filename=file.getName()+" at "+file.getParent();
				if (file.isDirectory())
				{
					deletefile(file.getAbsolutePath());
				}
				if (file.delete())
				{
					System.out.println(filename+" deleted successfully");
				} 
				else 
				{
					System.out.println("Failed to delete "+filename);
				}
			}
		}
		String currfile = curr.getName()+" at "+curr.getParent();
		if (curr.delete()) 
		{
			System.out.println(currfile+" deleted successfully");
		} 
		else 
		{
			System.out.println("Failed to delete " + currfile);
		}
	}
}
