package com.service;

import java.util.List;

import com.bean.Subjects;
import com.dao.SubjectsDao;
public class SubjectsService {
SubjectsDao ss = new SubjectsDao();
    
    public String storeSubjects(Subjects subject) {
        if(ss.storeSubjects(subject)>0) {
            return "Subject details stored successfully";
        }else {
            return "Subject details didn't store";
        }
    }
    
    public List<Subjects> findAllSubject() {
        return ss.findAllSubjects();
    }

}
