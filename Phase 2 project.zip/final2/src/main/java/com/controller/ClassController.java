package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Classes;
import com.service.ClassesService;

/**
 * Servlet implementation class ClassController
 */
public class ClassController extends HttpServlet {
	private static final long serialVersionUID = 1L;
        
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClassController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		ClassesService cs=new ClassesService();
		List<Classes> listOfClass=cs.findAllClasses();
		HttpSession hs=request.getSession();
		hs.setAttribute("listOfClass",listOfClass);
		response.setContentType("text/html");
		response.sendRedirect("viewClasses.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
        PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		int cid=Integer.parseInt(request.getParameter("cid"));
		String csec=request.getParameter("csec");
		int sbcid=Integer.parseInt(request.getParameter("sbcid"));
		int tcid=Integer.parseInt(request.getParameter("tcid"));
		int scid=Integer.parseInt(request.getParameter("scid"));
		
		Classes c=new Classes();
		c.setCid(cid);
		c.setCsec(csec);
		c.setSbcid(sbcid);
		c.setTcid(tcid);
		c.setScid(scid);
	
		 ClassesService cs = new ClassesService();
	        String result = cs.storeClasses(c);
	        pw.print(result);
	        RequestDispatcher rd = request.getRequestDispatcher("storeClasses.jsp");
	        rd.include(request, response);
	}

}
