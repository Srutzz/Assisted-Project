package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Subjects {
	@Id
	private int sbid;
	private String sbname;
	public int getSbid() {
		return sbid;
	}
	public void setSbid(int sbid) {
		this.sbid = sbid;
	}
	public String getSbname() {
		return sbname;
	}
	public void setSbname(String sbname) {
		this.sbname = sbname;
	}
	@Override
	public String toString() {
		return "Subjects [sbid=" + sbid + ", sbname=" + sbname + "]";
	}
}
