package assistedproject3;

public class range {
	static int k=16;
    static int a=100000; 
    static long b[][] = new long[a][k + 1]; 
    static void abc(int arr[], int n) 
    { 
        for (int i=0;i<n;i++) 
            b[i][0]=arr[i]; 
        for (int j=1;j<=k;j++) 
            for (int i=0;i<=n-(1<<j);i++) 
                b[i][j]=b[i][j-1]+b[i+(1<<(j-1))][j-1]; 
    } 
    static long q(int l, int r) 
    {
        long ans=0; 
        for (int j=k;j>=0;j--)  
        { 
            if (l+(1<<j)-1<=r)  
            { 
                ans=ans+b[l][j];
                l+=1<<j; 
            } 
        } 
        return ans; 
    }
    public static void main(String args[]) 
    { 
        int arr[] = {7,45,3,9,12,46}; 
        int n=arr.length; 
        abc(arr,n); 
        System.out.println(q(0,5)); 
        System.out.println(q(3,5)); 
        System.out.println(q(2,4)); 
    } 
}
