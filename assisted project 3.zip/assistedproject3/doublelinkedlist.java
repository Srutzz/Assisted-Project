package assistedproject3;
public class doublelinkedlist {
	Node head; 
	class Node 
	{ 
	    int data; 
	    Node prev; 
	    Node next; 
	    Node(int d) 
	    { 
	        data=d; 
	    } 
	}
	public void push(int newdata) 
	{ 
	    Node newnode=new Node(newdata); 
	    newnode.next=head; 
	    newnode.prev=null; 
	    if (head!=null) 
	    head.prev=newnode; 
	    head=newnode; 
	} 
	public void InsertAfter(Node prevnode, int newdata) 
	{ 
	    if (prevnode==null) 
	    { 
	        System.out.println("Previous node cannot be NULL"); 
	        return; 
	    } 	
	    Node newnode=new Node(newdata); 
	    newnode.next=prevnode.next; 
	    prevnode.next=newnode; 
	    newnode.prev=prevnode; 
	    if (newnode.next!=null) 
	    newnode.next.prev=newnode; 
	} 
	void append(int newdata) 
	{ 
	    Node newnode=new Node(newdata); 
	  	Node last=head; 
	    newnode.next=null;
	    if (head==null) 
	    { 
	    	newnode.prev=null; 
	    	head=newnode; 
	        return; 
	    } 
	    while (last.next!=null) 
	    	last=last.next; 
	    last.next=newnode; 
	    newnode.prev=last; 
	} 
	public void printlist(Node node) 
	{ 
	    Node last=null; 
	    System.out.println("Forward direction traversal"); 
	    while (node!=null) 
	    { 
	        System.out.print(node.data+" "); 
	        last=node;
	        node=node.next; 
	    } 
	    System.out.println(); 
	    System.out.println("Reverse direction traversal"); 
	    while (last!=null) 
	    { 
	         System.out.print(last.data+" "); 
	         last=last.prev; 
	    } 
	}
	public static void main(String[] args) 
	{
		doublelinkedlist a=new doublelinkedlist();
	    a.append(5); 
	    a.push(3);
	    a.push(2); 
	    a.append(8); 
	    a.InsertAfter(a.head.next,4); 
	    a.printlist(a.head); 
	 } 

}
