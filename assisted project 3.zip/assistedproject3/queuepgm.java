package assistedproject3;
import java.util.*;
public class queuepgm {
	public static void main(String[] args) 
	{
	    Queue<String> q = new LinkedList<>();
	    q.add("Idly");
	    q.add("Dosa");
	    q.add("Paratha");
	    q.add("Chapathi");
	    q.add("Pongal");
	    System.out.println("Queue: " + q);
		q.remove();
		System.out.println("After removing one element,Queue: " + q);
		System.out.println("Size of Queue : " + q.size());
		q.remove();
		System.out.println("After removing one element,Queue: " + q);
		System.out.println("Size of Queue : " + q.size());
	}
}
