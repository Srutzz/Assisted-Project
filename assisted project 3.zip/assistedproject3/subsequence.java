package assistedproject3;
public class subsequence {
	static int max=1;
	subsequence s=new subsequence();
	public static void main(String[] args)
	{
		int arr[]= {1,2,3,4,5,10,20,30,40,50};
	    int n=arr.length;
	    int e=listing(arr,n);
	    System.out.println("Length of list : "+e);
	}
	static int listing(int arr[],int n)
	{
		if(n==1)
			return 1;
	    int r,m=1;
	    for(int i=1;i<n;i++)
	    {
	    	r=listing(arr,i);
	    	if(arr[i-1]<arr[n-1]&&r+1>m)
	    		m=r+1;
	    }
	    if(max<m)
	    	max=m;
	    return m;
	}
}
