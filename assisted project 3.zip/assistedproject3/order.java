package assistedproject3;
public class order {
	public static void main(String[] args)
    {
        Integer arr[] = new Integer[] {2,9,1,6,3};
        int n=4;
        System.out.print("4th smallest element : " + smallest(arr,n));
    }
	public static int smallest(Integer[] arr,int n)
    {
		int a=arr.length;
		for (int i=0;i<a;i++)   
        {  
            for (int j=i+1;j<a;j++)   
            {  
                int temp = 0;  
                if (arr[i]>arr[j])   
                {  
                    temp=arr[i];  
                    arr[i]=arr[j];  
                    arr[j]=temp;  
                }  
            }  
        }
        return arr[n - 1];
    }
}
