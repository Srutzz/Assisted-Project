package assistedproject3;
public class singlylinkedlist {
	Node head; 
	static class Node 
    { 
    		int data; 
    		Node next; 
    		Node(int d) 
    		{ 
        		data = d; 
        		next = null; 
    		} 
	} 
	public static singlylinkedlist insert(singlylinkedlist list, int data) 
	{ 
    		Node newnode=new Node(data); 
    		newnode.next=null; 
    		if (list.head==null) 
            { 
        			list.head=newnode; 
    		} 
    		else 
            { 
         		Node last=list.head; 
        		while (last.next!=null) 
                {    
       				last=last.next; 
       			} 
	       		last.next=newnode; 
    		} 
    		return list; 
	} 
	public static void printList(singlylinkedlist list) 
	{	 
    		Node currNode=list.head; 
    		System.out.print("LinkedList: "); 
    		while (currNode!=null) 
            { 
          			System.out.print(currNode.data+" "); 
           			currNode=currNode.next; 
    		} 
    		System.out.println(); 
	} 
	public static singlylinkedlist deleteByKey(singlylinkedlist list, int key) 
	{ 
       		Node currNode=list.head,prev=null; 
    		if (currNode!=null&&currNode.data==key) 
            { 
        			list.head = currNode.next; 
        			System.out.println(key+" deleted"); 
        			return list; 
    		} 
    		while (currNode!=null&&currNode.data!=key) 
            { 
        			prev=currNode; 
        			currNode=currNode.next; 
    		} 
    		if (currNode!=null) 
            { 
        			prev.next=currNode.next; 
        			System.out.println(key+" deleted"); 
    		} 
    		if (currNode==null) 
            { 
        			System.out.println(key+" not found"); 
    		} 
    		return list; 
	} 
	public static void main(String[] args) 
	{ 
		    singlylinkedlist list = new singlylinkedlist(); 
      		list = insert(list,2); 
    		list = insert(list,6); 
    		list = insert(list,3); 
    		list = insert(list,18); 
    		list = insert(list,5); 
    		list = insert(list,0); 
    		printList(list); 
    		deleteByKey(list,18); 
    		printList(list); 
   		    deleteByKey(list,11); 
    		printList(list); 
	} 

}
