package assistedproject3;

public class sub {
	public static void main(String[] args)
	{
		 int[] num={3,8,2,50,32,12,9,1,16,5};
		 subsequence(num);
    }
	public static void subsequence(int[] num)
	{
		int n=num.length;
		String[] p=new String[n];
		int[] s=new int[n];
		for(int i=0;i<n;i++)
		{
			s[i]=1;
			p[i]=num[i]+" " ;
		}
		int max=1; 
		for(int i=1;i<n;i++)
		{ 
			for(int j=0;j<n;j++)
			{
				if(num[i]>num[j]&&s[i]<s[j]+1)
				{ 
					s[i]=s[j]+1;
			        p[i]=p[j]+num[i]+" "; 
			        if(max<s[i])
				    max=s[i];
			    }
		    }
		}
		for(int i=1;i<n;i++)
		{
		    if(s[i]==max)
			System.out.println("Longest increasing subsequences is "+p[i]);
		}
	}
}
