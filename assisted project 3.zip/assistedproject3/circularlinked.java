package assistedproject3;
public class circularlinked {
	static class Node 
	{ 
		int data; 
    	Node next; 
       	Node(int d) 
   		{ 
       		data=d; 
       		next=null; 
    	} 
    }
    Node head; 
    circularlinked()   
    { 
        head=null; 
    } 
	void sortedInsert(Node newnode) 
	{ 
    	Node curr=head; 
        if (curr==null) 
    	{ 
       		newnode.next=newnode; 
       		head=newnode; 
		} 
        else if (curr.data>=newnode.data) 
    	{ 
            while (curr.next!=head) 
            curr=curr.next; 
		    curr.next=newnode; 
            newnode.next=head; 
            head=newnode; 
    	} 
    	else
    	{
            while (curr.next!=head&&curr.next.data<newnode.data) 
   			curr=curr.next; 
			newnode.next=curr.next; 
        	curr.next=newnode; 
    	} 
    }
    void printList() 
	{ 
    	if (head!=null) 
   		{ 
        	Node temp=head; 
       		do
   			{ 
       			System.out.print(temp.data+" "); 
            	temp=temp.next; 
        	}  while (temp!=head); 
    	} 
	}
    public static void main(String[] args) 
	{ 
	    circularlinked list=new circularlinked(); 
    	int arr[]=new int[] {3,7,2,4,1,9}; 
   		Node temp=null; 
   		for (int i=0;i<6;i++) 
   		{ 
       		temp=new Node(arr[i]); 
       		list.sortedInsert(temp); 
    	} 
        list.printList(); 
	}
}
