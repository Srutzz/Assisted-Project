package assistedproject3;
public class arrayrotation {
	public static void main(String[] args) {
        	int arr[] = {1,2,3,4,5,6,7,8,9,10}; 
        	rotate(arr, 5); 
        	int e=arr.length;
       		for(int i=0;i<e;i++){
           		System.out.print(arr[i]+" ");
       		}
	}
	public static void rotate(int[] num, int n) {
		int a=num.length;
		if(n>a) 
   			n=n%a;
		int[] r = new int[a];
		for(int i=0; i < n; i++){
    			r[i] = num[a-n+i];
		}
		int j=0;
		for(int i=n; i<a; i++){
    			r[i] = num[j];
                j++;
		}
		System.arraycopy(r,0,num,0,a);
    }
}
