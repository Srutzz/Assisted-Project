package assistedproject3;
public class stackpgm {
	int top; 
	static final int max=100; 
	int a[]=new int[max];  
	int push(int x) 
	{ 
    	if(top>=(max-1)) 
    	{ 
       		System.out.println("Stack Overflow"); 
       		return 0; 
    	} 
    	else
    	{ 
        	a[++top]=x; 
        	System.out.println(x+" pushed into stack"); 
        	return 1; 
    	} 
	}
	int pop() 
	{ 
    	if(top<0) 
    	{ 
    		System.out.println("Stack Underflow"); 
       		return 0; 
    	} 
   		else
   		{ 
   			int x=a[top--]; 
       		return x; 
    	} 
	} 
	boolean isEmpty() 
	{ 
    	return (top<0); 
	} 
	stackpgm() 
	{ 
    	top=-1; 
	} 
	public static void main(String args[])
    {
		stackpgm s = new stackpgm(); 
    	s.push(1); 
    	s.push(2); 
    	s.push(3); 
    	s.push(4);
    	s.push(5);
    	System.out.println(s.pop() + " popped from stack"); 
    	System.out.println(s.pop() + " popped from stack");
	}
}
